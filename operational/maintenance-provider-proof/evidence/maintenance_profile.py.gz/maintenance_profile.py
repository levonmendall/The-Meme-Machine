import cProfile,sys,unittest,pstats,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repo'))
from operational.tests import network_guard
from meme_machine.operational.artifact_storage import Scratch
from meme_machine.solana_maintenance_runtime import MaintenanceRuntime
network_guard();original=MaintenanceRuntime.turn;profiles={}
def turn(self,*a):
 p=profiles.setdefault(threading.get_ident(),cProfile.Profile());p.enable()
 try:return original(self,*a)
 finally:p.disable()
MaintenanceRuntime.turn=turn
with Scratch() as scratch:
 result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromName('tests.test_run381_archive_scheduling.BoundedArchiveRetirementTests.test_eligible_reader_and_all_scopes_progress_under_source_pressure'))
 scratch.success=result.wasSuccessful()
for i,p in enumerate(profiles.values()):
 with Path(sys.argv[1]+str(i)+'.txt').open('w') as f:pstats.Stats(p,stream=f).strip_dirs().sort_stats('cumtime').print_stats(45)
