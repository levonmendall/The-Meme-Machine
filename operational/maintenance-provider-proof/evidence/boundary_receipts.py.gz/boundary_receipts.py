"""Capture real failure-injection observations without altering decisions."""
import hashlib,json,sys,threading,time,unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'repo'))
from operational.tests import network_guard
network_guard()
from meme_machine.operational.artifact_storage import Scratch
from engineering.solana_capacity.proof_limits import Budget
from engineering.solana_capacity.proof_host import ResourceWatch,WriteAdmission

target=Path(sys.argv[1]).resolve();events=[];tests=[];lock=threading.RLock();current=None
def record(kind,reason,**values):
    with lock:events.append(dict(test=current,kind=kind,reason=reason,**values))
original_fail=Budget.fail
def fail(budget,reason):
    record('atomic_provider_or_scheduler_stop',reason,counts=dict(budget.counts))
    return original_fail(budget,reason)
original_check=ResourceWatch.check
def check(watch,row):
    result=original_check(watch,row)
    if result:record('independent_resource_stop',result,measurement=row)
    return result
original_reserve=WriteAdmission.reserve
def reserve(admission,*a,**kw):
    result=original_reserve(admission,*a,**kw)
    if result:record('pre_syscall_write_refusal',result,cumulative_reserved=admission.writes,stock_reserved=admission.stock)
    return result
class Result(unittest.TextTestResult):
    def startTest(self,test):
        global current
        current=test.id();super().startTest(test)
    def addSuccess(self,test):tests.append(dict(test=test.id(),result='PASS'));super().addSuccess(test)

with Scratch() as scratch,patch.object(Budget,'fail',fail),patch.object(ResourceWatch,'check',check),patch.object(WriteAdmission,'reserve',reserve):
    started=time.monotonic()
    suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_pump_pons_proof')
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite);scratch.success=result.wasSuccessful()
    report=dict(schema='offline-boundary-observations-v1',passed=result.wasSuccessful(),tests=result.testsRun,
        elapsed_seconds=time.monotonic()-started,provider_dispatch_mode='OFFLINE guarded',
        interpretations='Internal reduced boundary injections exercise exact production limiter decisions. Wrapper observations do not replace or suppress decisions/assertions.',
        cases=tests,observations=events)
    target.write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())
