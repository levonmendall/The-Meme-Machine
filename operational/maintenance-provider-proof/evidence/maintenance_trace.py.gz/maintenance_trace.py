import json,os,time,unittest,threading,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repo'))
from operational.tests import network_guard
from meme_machine.operational.artifact_storage import Scratch
network_guard()
from tests import test_production_maintenance_arbiter as a,test_run381_archive_scheduling as b
from meme_machine.solana_owner_admission import OwnerAdmission
rows=[];starts=[];idle=[];turns=[]
native_idle=OwnerAdmission.idle
async def observed_idle(self,stop,worker=None):
 start=time.monotonic()
 try:return await native_idle(self,stop,worker)
 finally:idle.append(dict(seconds=time.monotonic()-start,positive=self.hint and self.hint.positive,epoch=self.epoch))
OwnerAdmission.idle=observed_idle
from meme_machine.solana_maintenance_runtime import MaintenanceRuntime
native_turn=MaintenanceRuntime.turn
def observed_turn(self,*args):
 start=time.monotonic()
 try:return native_turn(self,*args)
 finally:turns.append(dict(seconds=time.monotonic()-start,at=start-starts[-1],event=dict(self.ring[-1]) if self.ring else None))
MaintenanceRuntime.turn=observed_turn
native_case=a.run_case
async def observed_case(**kw):
 started=time.monotonic();starts.append(started);i=len(idle);t=len(turns)
 box=await native_case(**kw)
 rows.append(dict(seconds=time.monotonic()-started,errors=[type(e).__name__ for e in box['errors']],turns=box['turns'],clock=box['clock'].monotonic(),operations=box['operations'],counters=box['counters'],owner=box['owner'].telemetry(),last_events=list(box['runtime'].ring)[-4:],idle=idle[i:],timed_turns=turns[t:]))
 return box
a.run_case=b.run_case=observed_case
names=['tests.test_production_maintenance_arbiter.ProductionServeTests.test_simultaneous_high_debt_and_three_scopes','tests.test_run381_archive_scheduling.BoundedArchiveRetirementTests.test_eligible_reader_and_all_scopes_progress_under_source_pressure','tests.test_run381_archive_scheduling.BoundedArchiveRetirementTests.test_sustained_ready_work_has_bounded_two_sided_service']
with Scratch() as scratch:
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
 Path(sys.argv[1]).write_text(json.dumps(rows,indent=2)+'\n');scratch.success=result.wasSuccessful()
raise SystemExit(not result.wasSuccessful())
