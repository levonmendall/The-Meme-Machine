"""Read-only source inventory; never opens production SQLite or credentials."""
import hashlib,json,subprocess,sys,time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
baseline=json.loads((ROOT/'audit/BASELINE.json').read_text())
paths=[r['path'] for r in baseline]+['/root/Documents/Codex/2026-10-08/the-meme-machine-robinhood-payg-alchemy/repo']
rows=[]
for name in paths:
    p=Path(name)
    def git(*a):return subprocess.check_output(['git','-C',str(p),*a],timeout=10)
    patch=git('diff','--binary','HEAD')
    entries=[]
    for raw in git('ls-files','--others','--exclude-standard','-z').split(b'\0'):
        if not raw:continue
        relative=raw.decode();q=p/relative
        if q.is_file():entries.append(dict(path=relative,bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
    rows.append(dict(path=name,commit=git('rev-parse','HEAD').decode().strip(),
        status=git('status','--porcelain').decode(),patch_sha256=hashlib.sha256(patch).hexdigest(),untracked=entries,
        worktrees=git('worktree','list','--porcelain').decode(),modified_by_this_assignment=False))
report=dict(captured_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),rows=rows,
    production_databases_opened=0,production_service_mutations=0,
    interpretation='Concurrent tasks may advance their own worktrees; this assignment only modifies its dedicated worktree. Initial diffs remain preserved locally.')
target=ROOT/'audit'/sys.argv[1]
target.write_text(json.dumps(report,indent=2)+'\n')
print('Recorded',len(rows),'read-only source inventories')
