import sqlite3,sys,time,unittest,json,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repo'))
from operational.tests import network_guard
from meme_machine.operational.artifact_storage import Scratch
network_guard();stats={};lock=threading.Lock();original=sqlite3.connect
class Connection(sqlite3.Connection):
 def execute(self,sql,parameters=(),/):
  start=time.perf_counter()
  try:return super().execute(sql,parameters)
  finally:
   elapsed=time.perf_counter()-start
   if threading.current_thread().name=='solana-evidence-owner':
    with lock:
     item=stats.setdefault(sql,dict(seconds=0,count=0));item['seconds']+=elapsed;item['count']+=1
sqlite3.connect=lambda *a,**kw:original(*a,**dict(kw,factory=Connection))
with Scratch() as scratch:
 result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromName('tests.test_run381_archive_scheduling.BoundedArchiveRetirementTests.test_eligible_reader_and_all_scopes_progress_under_source_pressure'))
 scratch.success=result.wasSuccessful()
Path(sys.argv[1]).write_text(json.dumps(sorted([dict(sql=sql,**v) for sql,v in stats.items()],key=lambda v:-v['seconds'])[:35],indent=2)+'\n')
